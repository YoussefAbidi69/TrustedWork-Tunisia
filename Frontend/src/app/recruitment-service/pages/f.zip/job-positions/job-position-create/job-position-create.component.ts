import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JobPositionService } from '../../../services/job-position.service';
import { ActivatedRoute } from '@angular/router';
@Component({
    selector: 'app-job-position-create',
    templateUrl: './job-position-create.component.html',
    styleUrls: ['./job-position-create.component.css']
})
export class JobPositionCreateComponent implements OnInit {
    form!: FormGroup;
    loading = false;

    contractTypes = ['CDI', 'CDD', 'FREELANCE', 'STAGE', 'ALTERNANCE'];

    statuses = [
        'DRAFT',
        'PUBLISHED',
        'PAUSED',
        'CLOSED',
        'FILLED'
    ];

    constructor(
        private fb: FormBuilder,
        private jobPositionService: JobPositionService,
        private router: Router,
        private route: ActivatedRoute
    ) { }

    ngOnInit(): void {

        this.form = this.fb.group({
            titre: ['', Validators.required],
            description: ['', Validators.required],
            typeContrat: ['CDI', Validators.required],
            salaireMin: [0],
            salaireMax: [0],
            localisation: [''],
            remote: [false],
            experienceRequiseAns: [0],
            skillsRequis: [''],
            deadline: [''],
            status: ['DRAFT']
        });

        const id = this.route.snapshot.paramMap.get('id');

        if (id) {
            this.jobPositionService.getById(Number(id)).subscribe(data => {
                this.form.patchValue(data);
            });
        }

    }

    onSubmit(): void {

        if (this.form.invalid) return;

        const id = this.route.snapshot.paramMap.get('id');

        if (id) {

            this.jobPositionService.update(Number(id), this.form.value)
                .subscribe(() => {
                    this.router.navigate(['/recruitment/job-positions']);
                });

        } else {

            this.jobPositionService.create(this.form.value)
                .subscribe(() => {
                    this.router.navigate(['/recruitment/job-positions']);
                });

        }

    }
}
